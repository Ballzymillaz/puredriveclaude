# PureDrive — Guide d'intégration des pages React

## Structure des fichiers créés

```
src/
├── App.jsx                          ← Routeur principal + logique de simulation
│
├── components/
│   ├── Layout.jsx                   ← Topbar + Sidebar + navigation multi-rôles
│   ├── ui.jsx                       ← Tous les composants UI réutilisables
│   └── modals/
│       ├── AddDriverModal.jsx       ← Modale ajout motorista + AddVehicle, AddCompany, AddMaintenance
│       ├── AddVehicleModal.jsx      ← Re-export
│       ├── AddCompanyModal.jsx      ← Re-export
│       ├── AddMaintenanceModal.jsx  ← Re-export
│       ├── LoanApprovalModal.jsx    ← Modale approbation prêt (admin)
│       └── LoanRequestModal.jsx    ← Modale demande prêt (motorista) avec calculateur live
│
└── pages/
    ├── AdminDashboard.jsx           ← Dashboard global avec KPIs, chart, frotas, top drivers
    ├── Drivers.jsx                  ← Table motoristas avec search/filter
    ├── Vehicles.jsx                 ← Table véhicules avec statuts TVDE
    ├── VehicleDetail.jsx            ← Détail véhicule: infos, rentabilité, historique maintenance
    ├── Payments.jsx                 ← Tableau paiements hebdo + flux financier
    ├── Companies.jsx                ← Cards companies avec toggles UPI/prêts/achat/ranking
    ├── Fleets.jsx                   ← Cards frotas avec occupancy
    ├── Loans.jsx                    ← Gestion empréstimos: stats + tableau pendentes
    ├── Purchase.jsx                 ← Simulateur opção de compra + tableau actifs
    ├── Ranking.jsx                  ← Podium top 3 + tableau complet
    ├── Reports.jsx                  ← Relatório com chart évolution + déductions
    ├── Maintenance.jsx              ← Timeline maintenance + dashboard rentabilité
    ├── UPI.jsx                      ← Système UPI avec vesting par motorista
    ├── Messages.jsx                 ← Chat interface avec liste conversations
    └── MotoristaDashboard.jsx       ← Vue motorista: pagamento, achat, UPI, actions rapides
```

---

## Comment intégrer dans votre projet existant

### 1. Remplacer App.jsx
Copiez `src/App.jsx` dans `frontend/src/App.jsx`.

### 2. Créer les dossiers
```bash
mkdir -p frontend/src/components/modals
mkdir -p frontend/src/pages
```

### 3. Copier tous les fichiers
```bash
cp components/Layout.jsx   frontend/src/components/
cp components/ui.jsx       frontend/src/components/
cp components/modals/*.jsx frontend/src/components/modals/
cp pages/*.jsx             frontend/src/pages/
```

### 4. Adapter les imports API
Dans chaque page, remplacer les données statiques par des appels API :

```jsx
// AVANT (données statiques)
const DRIVERS = [ { name: "Carlos Mendes", ... }, ... ]

// APRÈS (votre client API)
import { drivers } from "@/api/client";
const [data, setData] = useState([]);
useEffect(() => {
  drivers.list().then(res => setData(res.entities));
}, []);
```

---

## Logique métier implémentée

### Navigation multi-pages
- `App.jsx` gère `currentPage` en state React
- `navigate(pageId)` est passé en prop à tous les composants
- Les pages sont enregistrées dans `PAGES` (dictionnaire id → composant)

### Simulation de rôles (3 rôles)
```
admin         → sidebar complète (toutes les pages)
motorista     → sidebar réduite (dashboard, paiements, ranking, achat, UPI)
fleet-manager → sidebar fleet (drivers, vehicles, payments, loans, ranking, reports)
fleet-saas    → sidebar fleet + notice "UPI/Achat non disponibles"
```
- `simulate(role)` change le rôle, l'avatar topbar, la sidebar et la page par défaut
- `stopSimulation()` revient à admin
- Badge orange "A simular: ..." s'affiche dans la topbar

### Calculateur de prêt (LoanRequestModal)
```
interest = amount × 0.01 × weeks
total    = amount + interest
```
- Calcul en temps réel (useState)
- Options: 2, 4, 8, 12, 24 semaines

### Simulateur d'achat (Purchase.jsx)
```
price_final = market_price × 1.25   (marge +25%)
Plan dégressif trimestriel:
  T1 (m1-3)  : base × 1.03
  T2 (m4-6)  : base × 0.99
  T3 (m7-9)  : base × 0.97
  T4 (m10-12): base × 0.96
  T5+ (m13+) : base × 0.94
```
- Contrainte TVDE: limite 7 ans à partir de la 1ère immatriculation
- Options désactivées si durée > maxMonths du véhicule

### Toggle type d'entreprise (Companies.jsx)
- PureDrive: UPI ✅, Prêts ✅, Achat ✅, Ranking ✅
- SaaS: UPI ❌ (désactivé), Prêts ✅, Achat ❌ (désactivé), Ranking ✅

### Charts (ChartBars dans ui.jsx)
```jsx
// Données normalisées automatiquement (max = 100%)
<ChartBars
  data={[28400, 31200, 29800, 33100, 30200, 32500, 34820]}
  labels={["Sem 6", ..., "Sem 12"]}
/>
// Dernière barre = barre active (couleur accent)
```

### Month dots progress (MonthDots dans ui.jsx)
```jsx
<MonthDots total={24} paid={15} current={15} />
// paid=vert, current=amber (animé), reste=gris
```

---

## Données de test incluses

| Page | Données |
|------|---------|
| AdminDashboard | 7 semaines revenus, 3 frotas, 3 top drivers, 3 prêts pendentes |
| Drivers | 5 motoristas avec rank, score, UPI, état |
| Vehicles | 3 véhicules avec états (actif/maintenance) |
| Payments | 3 motoristas semaine 12 (Uber + Bolt + déductions) |
| Companies | PureDrive Lda + FleetPro SaaS |
| Fleets | Lisboa + Porto + FleetPro |
| Loans | 3 pedidos pendentes + stats |
| Purchase | Toyota Camry + Kia EV6 disponibles, 1 option active |
| Ranking | Top 3 podium + 3 autres positions |
| Reports | 6 mois évolution + déductions |
| Maintenance | 3 entrées historique |
| UPI | 4 motoristas avec vesting |
| Messages | Chat Carlos Mendes + 2 autres conversations |
| MotoristaDash | Vue Carlos Mendes semaine 12 |

---

## Variables CSS requises

Votre fichier CSS doit définir ces variables (déjà dans puredrive.html) :

```css
:root {
  --bg, --surface, --surface2, --surface3
  --border, --border2
  --accent, --accent2, --accent-dim, --accent-glow
  --amber, --amber-dim
  --red, --red-dim
  --blue, --blue-dim
  --purple, --purple-dim
  --text, --text2, --text3
  --font-display, --font-body, --font-mono
  --radius, --radius-lg
  --sidebar-w (240px), --topbar-h (56px)
}
```
